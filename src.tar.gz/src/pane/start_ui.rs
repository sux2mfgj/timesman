use super::{PaneModel, PaneRequest, PaneResponse};

#[derive(Copy, Clone)]
pub enum UIRequest {
    Close,
}

#[derive(Copy, Clone)]
pub enum UIResponse {
    Ok,
    Err,
}

pub trait StartPaneTrait {
    fn update(&mut self, msg: &Vec<UIResponse>) -> Result<Vec<UIRequest>, String>;
}

pub struct StartPane {}

impl StartPaneTrait for StartPane {
    fn update(&mut self, msg: &Vec<UIResponse>) -> Result<Vec<UIRequest>, String> {
        todo!();
    }
}

impl StartPane {
    pub fn new() -> Self {
        Self {}
    }
}

#[cfg(test)]
mod tests {

    use super::*;

    #[test]
    fn test_example() {}
}
