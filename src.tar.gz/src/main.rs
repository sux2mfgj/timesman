mod pane;

fn main() {
    println!("Hello, world!");
    let mut model = pane::init_pane();
    model.update(&vec![]).unwrap();
}

//TODO define a original error type

#[cfg(test)]
mod tests {

    use super::*;

    #[test]
    fn test_example() {}
}
